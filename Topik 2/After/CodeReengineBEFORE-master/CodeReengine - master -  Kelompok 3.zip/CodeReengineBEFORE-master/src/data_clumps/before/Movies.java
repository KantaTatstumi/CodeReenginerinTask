package data_clumps.before;

import java.util.*;

public class Movies {
	private String movieName;

	public Movies(String movieName) {
		this.movieName = movieName;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	
}
